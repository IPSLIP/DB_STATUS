from selenium import webdriver
from selenium.webdriver.common.by import By
import time,random
options = webdriver.ChromeOptions()
options.add_experimental_option('excludeSwitches', ['enable-logging'])
options.add_argument('--disable-gpu')
tt = []
for year in range(2000,2023):
    for month in range(1,13):
        if month in [1,3,5,7,8,10,12]:
            dr = 31
        elif month==2:
            if year % 4 == 0:
                dr = 29
            else:
                dr = 28
        else:
            dr = 30
        for day in range(2,dr):
            tt.append([day,month,year])

ddg_containers = set()
driver = webdriver.Chrome(r'C:\Users\12246\Downloads\chromedriver_win32\chromedriver.exe',options=options)
driver.implicitly_wait(8)
driver.minimize_window()
    
while True:
    ddg_containers.update(open(r'C:\Users\12246\Desktop\DB_STATUS\ddg_containers.txt','r',encoding='utf-8',newline='').read().splitlines())
    ddg_containers_text = open(r'C:\Users\12246\Desktop\DB_STATUS\ddg_containers.txt','a',encoding='utf-8',newline='')
    random.shuffle(tt)
    urls_tried = 0
    driver.execute_script("window.open('','_blank');")
    first = True
    for trip in tt:
        year = trip[2]
        month = trip[1]
        day = trip[0]
        url_to_try = 'https://duckduckgo.com/?q=site%3Ablob.core.windows.net&t=h_&df='+str(year)+'-'+str(month).zfill(2)+'-'+str(day-1).zfill(2)+'..'+str(year)+'-'+str(month).zfill(2)+'-'+str(day).zfill(2)+'&ia=web&num=100'
        x = driver.get(url_to_try)
        if first:
            for i in range(1,10):
                try:
                    driver.switch_to.window(driver.window_handles[i]);
                    driver.close();
                except:
                    pass
            driver.switch_to.window(driver.window_handles[0]);
            first = False
        y = driver.find_elements(By.TAG_NAME, "a")
        for a in y:
            try:
                if 'blob.core.windows.net' in a.text and a.text.split(' › ')[0]+"/"+a.text.split(' › ')[1] not in ddg_containers:
                    print("NEW POTENTIAL AZURE BLOG\t"+a.text.split(' › ')[0]+"/"+a.text.split(' › ')[1]+" ADDED, "+str(len(ddg_containers))+" SO FAR")
                    ddg_containers_text.write(a.text.split(' › ')[0]+"/"+a.text.split(' › ')[1]+'\n')
                    ddg_containers_text.flush()
                    ddg_containers.add(a.text.split(' › ')[0]+"/"+a.text.split(' › ')[1])
            except Exception as e:
                #print("SKIPPING\t:"+str(e))
                pass
        time.sleep(0.75)
        urls_tried +=1
        if urls_tried>=30:
            print("30 URLS processed, reseting...")
            break