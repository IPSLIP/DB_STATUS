import shutil,time
while True:
    while True:
        rc = len(open(r'C:\Users\12246\Desktop\DB_STATUS\current_status - Copy.txt','r',encoding='utf-8').read().splitlines())
        if rc==10:
            break
        else:
            print("CURRENT LENGTH NOT 11 (it's "+str(rc)+"), WAITING...")
            time.sleep(5)
    row_number = 1
    while row_number!=11:
        output = open(r'C:\Users\12246\Desktop\DB_STATUS\index.html','w',newline='',encoding='utf-8')
        output.write("""
        <head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <title>IP SLIP</title>
        <style>
        div {text-align: center;}
        </style>
        </head>""")
        print("TRYING...")
        time.sleep(10)
        shutil.copy(r'C:\Users\12246\Desktop\DB_STATUS\current_status.txt',r'C:\Users\12246\Desktop\DB_STATUS\current_status - Copy.txt')
        for row in open(r'C:\Users\12246\Desktop\DB_STATUS\current_status - Copy.txt','r',encoding='utf-8').read().splitlines():
            if row_number==3:
                row = row.split('\t')
                output.write("<body><div>As of <b>"+row[0]+"</b> our team has identified:<br><br><b>"+'{:,}'.format(int(row[1]))+"</b> PUBLIC AZURE CONTAINERS WITH <b>"+'{:,}'.format(int(row[2]))+"</b> FILES CONTAINING <b>"+row[3].split(' ')[1].replace('(','').replace(')','')+" TB</b> OF DATA</div><br><br>")
            if row_number==6:
                row = row.split('\t')
                output.write("<div>As of <b>"+row[0]+"</b> our team has scanned and identified:<br><br><b>"+'{:,}'.format(int(row[1]))+"</b> UNIQUE FILE HASHES FROM <b>"+'{:,}'.format(int(row[2]))+"</b> PUBLIC GITHUB REPOSITORIES WITH <b>"+'{:,}'.format(int(row[3]))+"</b> FILES LIKELY CONTAINING PLAIN TEXT STRINGS OF PASSWORDS AND/OR API KEYS</div><br><br>")
            if row_number==9:
                row = row.split('\t')
                output.write("<div>As of <b>"+row[0]+"</b> our team has identified:<br><br><b>"+'{:,}'.format(int(row[1]))+"</b> PUBLIC S3 BUCKETS WITH <b>"+'{:,}'.format(int(row[2]))+"</b> FILES CONTAINING <b>"+row[3].split(' ')[1].replace('(','').replace(')','')+" TB</b> OF DATA</div><br><br>")
                
            row_number += 1
        output.write('<div>How to make your Amazon S3 Bucket PUBLIC/PRIVATE</div>')
        output.write('<div>Amazon provides the <b><a href="https://docs.aws.amazon.com/AmazonS3/latest/userguide/configuring-block-public-access-bucket.html">following guidance</a></b> for configuring access settings for your S3 buckets.</div>')
        output.write('<div>One thing of note for organizations. Since at least February 28, 2021, Amazon has the <b><a href="http://web.archive.org/web/20210228135942/https://docs.aws.amazon.com/AmazonS3/latest/userguide/configuring-block-public-access-bucket.html">following statement</a></b> around S3 buckets: "By default, new buckets, access points, and objects do not allow public access."</div>')
        output.write('<div>You need to both 1) disable public access for each of the S3 buckets in your account and 2) block public access to account settings. Amazon <a href="https://us-east-1.console.aws.amazon.com/s3/settings?region=us-east-1"> says</a>: "Public access is granted to buckets and objects through access control lists (ACLs), bucket policies, access point policies or all. In order to ensure that public access to all your S3 buckets and objects is blocked, turn on Block all public access. These settings apply account-wide for all current and future buckets and access points. AWS recommends that you turn on Block all public access, but before applying any of these settings, ensure that your applications will work correctly without public access. If you require some level of public access to your buckets or objects, you can customize the individual settings below to suit your specific storage use cases."</div>')
        #https://us-east-1.console.aws.amazon.com/s3/buckets/ipslipexamplebucket2?region=us-east-1&tab=permissions
        #https://[REGION].console.aws.amazon.com/s3/buckets/[BUCKETNAME]?region=[REGION]&tab=permissions
        #Or to go directly to editing
        #https://[REGION].console.aws.amazon.com/s3/bucket/[BUCKETNAME]/property/bpa/edit?region=[REGION]
        #include webpage that takes in user input (region (optional, default=us-east-1), bucketnames
        #In S3 bucket list, can sort to see "Objects can be public"
        output.write('</body>')
        output.flush()
        output.close()
    print("SLEEPING FOR THIRTEEN MINUTES")
    time.sleep(60*13)