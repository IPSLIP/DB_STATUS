import requests,time
from socket import timeout
from bs4 import BeautifulSoup


s3_bucket_file = open(r'C:\users\12246\desktop\db_status\gh\s3_buckets_20220421.txt','a',newline='',encoding='utf-8')
azure_container_file = open(r'C:\users\12246\desktop\db_status\gh\azure_containers_20220421.txt','a',newline='',encoding='utf-8')
while True:
    x = requests.get('https://buckets.grayhatwarfare.com/random/buckets',timeout=5).text
    soup = BeautifulSoup(x,'html.parser')
    for l in (soup.find_all('tr')):
        elems = l.text.strip().replace('\n','\t').split('\t')
        if len(elems)==14:
            rta = elems[6].split('.blob.core.windows.net')[0]+","+elems[13]
            
            if rta in open(r'C:\users\12246\desktop\db_status\gh\azure_containers_20220421.txt','r',encoding='utf-8').read():
                print("SKIPPING ROW:\t"+rta)
            else:
                print("NEW AZURE BLOB:\t"+rta)
                azure_container_file.write(rta+'\n')
                azure_container_file.flush()
        elif len(elems)>=7:
            rta = elems[6].split('.s3')[0]
            if rta in open(r'C:\users\12246\desktop\db_status\gh\s3_buckets_20220421.txt','r',encoding='utf-8').read():
                print("SKIPPING ROW:\t"+rta)
            else:
                print("NEW S3 BUCKET:\t"+rta)
                s3_bucket_file.write(rta+'\n')
                s3_bucket_file.flush()