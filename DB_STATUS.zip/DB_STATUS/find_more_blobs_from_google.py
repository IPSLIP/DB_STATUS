import requests,time
from socket import timeout
from bs4 import BeautifulSoup

outie = open(r'C:\users\12246\desktop\db_status\googleblobs_20220420.txt','w',newline='',encoding='utf-8')
for i in range(20):
    x = requests.get('https://www.google.com/search?q="blob.core.windows.net"&num=100&start='+str(100&i),timeout=5).text
    soup = BeautifulSoup(x,'html.parser')
    for l in (soup.find_all('a')):
        outie.write(l['href']+'\n')
        outie.flush()
    time.sleep(5)