import os,random
from tqdm import tqdm

while True:
    td = list(range(40052))
    random.shuffle(td)
    for i in tqdm(td):
        if os.path.exists(r'C:\Users\12246\Desktop\DB_STATUS\gh_api\webarchive_output_s3_'+str(i).zfill(5)+'.json'):
            print(str(i).zfill(5)+'.json already exists, skipping!')
        else:
            print("DOWNLOADING "+str(i).zfill(5)+'.json')
            os.system("curl -o .\\webarchive_output_S3_"+str(i).zfill(5)+'.json "https://web.archive.org/cdx/search/cdx?url=amazonaws.com/&matchType=domain&output=json&limit=100000&page='+str(i)+'"')