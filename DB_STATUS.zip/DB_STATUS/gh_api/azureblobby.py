import os,random
from tqdm import tqdm

while True:
    td = list(range(2029))
    random.shuffle(td)
    for i in tqdm(td):
        if os.path.exists(r'C:\Users\12246\Desktop\DB_STATUS\gh_api\webarchive_output_'+str(i).zfill(4)+'.json'):
            print(str(i).zfill(4)+'.json already exists, skipping!')
        else:
            print("DOWNLOADING "+str(i).zfill(4)+'.json')
            os.system("curl -o .\\webarchive_output_"+str(i).zfill(4)+'.json "https://web.archive.org/cdx/search/cdx?url=blob.core.windows.net/&matchType=domain&output=json&limit=100000&page='+str(i)+'"')