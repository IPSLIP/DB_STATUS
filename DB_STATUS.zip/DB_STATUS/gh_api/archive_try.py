import shutil,requests,time,random,queue,multiprocessing,threading,psycopg2
from datetime import datetime, timezone
import xml.etree.ElementTree as ET
from psycopg2 import Error
from urllib import parse
from socket import timeout
import itertools
try:
    q = queue.Queue()
    write_queue = queue.Queue()

    # Connect to an existing database
    connection = psycopg2.connect(user="postgres",
                                  password="T1g3rw00dz$$",
                                  host="192.168.0.144",
                                  port="5432",
                                  database="s3_bucket_scanner")
    # Create a cursor to perform database operations
    cursor = connection.cursor()
    
    def worker():
        # Connect to an existing database
        connection = psycopg2.connect(user="postgres",
                                      password="T1g3rw00dz$$",
                                      host="192.168.0.144",
                                      port="5432",
                                      database="s3_bucket_scanner")
        # Create a cursor to perform database operations
        cursor = connection.cursor()
        while True:
            item = q.get()
            try:
                r = requests.get(item,timeout=5).text
                # insert new ID into database
                no_error = True
                for error_message in ['The specified bucket does not exist']:
                    if error_message in r:
                        no_error = False
                        break
                dt = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
                row_to_add = [item,"",item,"",'The specified bucket does not exist',dt,0,'']
                if no_error:
                    row_to_add[4]="None"
                    root = ET.fromstring(r)
                    for i in root.iter():
                        tag = i.tag.replace('{http://s3.amazonaws.com/doc/2006-03-01/}','')
                        if tag=='NextContinuationToken':
                            row_to_add[7] = i.text
                            if item.find('&next-continuation-token=')>0:
                                q.put(item[:item.find('&next-continuation-token=')]+'&next-continuation-token='+i.text)
                            else:
                                q.put(item+'&next-continuation-token='+i.text)
                        elif tag=='Key':
                            row_to_add[1]= i.text.replace("'","%27")
                            scheme, netloc, path, query, fragment = parse.urlsplit(item.replace('?list-type=2','')+i.text)
                            path = parse.quote(path)
                            row_to_add[2]= parse.urlunsplit((scheme, netloc, path, query, fragment))
                        elif tag=='LastModified':
                            row_to_add[3]=i.text
                        elif tag=='Size':
                            row_to_add[6] = int(i.text)
                            sel_st = """SELECT * FROM aws_files WHERE URL='{0}' LIMIT 1""".format(row_to_add[2])
                            cursor.execute(sel_st)
                            record = cursor.fetchone()
                            connection.commit()
                            if record is None:
                                print("NEW FILE "+row_to_add[2]+" FOUND!")
                                write_queue.put(row_to_add)
                            else:
                                print("SKIPPING FILE "+row_to_add[2]+" (already in database)")
                            row_to_add = [item,"","","",row_to_add[4],dt,0,row_to_add[7]]
            except Exception as e:
                pass
            q.task_done()

    def worker_write():
        # Connect to an existing database
        connection = psycopg2.connect(user="postgres",
                                      password="T1g3rw00dz$$",
                                      host="192.168.0.144",
                                      port="5432",
                                      database="s3_bucket_scanner")
        # Create a cursor to perform database operations
        cursor = connection.cursor()
        while True:
            i = str(write_queue.get())
            try:
                insert_string = """INSERT INTO aws_files(PUBLIC_BUCKET,FILE_NAME,URL,LAST_MODIFIED,ERROR,ADDED_DATE,CONTENT_LENGTH,TRUNCATED) VALUES("""+i[1:-1]+""")"""
                cursor.execute(insert_string+";")
                print("EXECUTED QUERY\t"+insert_string+"...")
            except Exception as e:
                #print(str(e))
                print("ERROR WITH INSERT STRING\t"+insert_string+":\t"+str(e))
                pass
            connection.commit()
            write_queue.task_done()

    cpus=multiprocessing.cpu_count() #detect number of cores
    print("Creating %d threads" % cpus)
    write_ = False
    for i in range(8):
        t = threading.Thread(target=worker_write)
        t.daemon = True
        t.start()
    for i in range(8):
        t = threading.Thread(target=worker)
        t.daemon = True
        t.start()
    f = open(r'C:\Users\12246\Desktop\DB_STATUS\gh_api\webarchive_buckets.txt','r',encoding='utf-8').read().splitlines()
    random.shuffle(f)
    while True:
        for record in f:
            try:
                q.put(record+'/?list-type=2')
            except Exception as e:
                print("ERROR with url "+record[0]+":\t"+str(e))
                q.join()
                write_queue.join()
except Exception as e:
    print("ERROR:\t"+str(e))