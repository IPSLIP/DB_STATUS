import os,json,time
out = open(r'C:\Users\12246\Desktop\DB_STATUS\gh_api\webarchive_blobs.txt','a+',newline='',encoding='utf-8')
out.seek(0)
already_added = set()
already_added.update(out.read().splitlines())
while True:
    for i in range(2029):
        print("PAGE "+str(i))
        try:
            for row in json.loads(open(r'C:\Users\12246\Desktop\DB_STATUS\gh_api\webarchive_output_'+str(i).zfill(4)+'.json','r').read()):
                try:
                    temp = 'https://'+row[2].replace('https://','').replace('http://','').split('/')[0]+"/"+row[2].replace('https://','').replace('http://','').split('/')[1]
                    if temp not in already_added and len(row[2].replace('https://','').replace('http://','').split('/')[1])>0:
                        out.write(temp+'\n')
                        out.flush()
                        already_added.add(temp)
                        print("ADDED NEW ROW:\t"+temp+", "+str(len(already_added))+" NEW ROWS ADDED")
                except:
                    pass
        except Exception as e:
            print('ERROR WITH ROW "'+str(row)+'":\t'+str(e))