import os,json,time
out = open(r'C:\Users\12246\Desktop\DB_STATUS\gh_api\webarchive_buckets.txt','a+',newline='',encoding='utf-8')
already_added = set()
already_added.update(out.read().splitlines())

while True:
    error_count = 0
    for i in range(40052):
        try:
            for row in json.loads(open(r'C:\Users\12246\Desktop\DB_STATUS\gh_api\webarchive_output_s3_'+str(i).zfill(5)+'.json','r').read()):
                temp = 'https://'+row[2].replace('https://','').replace('http://','').split('/')[0]
                if temp not in already_added:
                    out.write(temp+'\n')
                    out.flush()
                    already_added.add(temp)
                    print("ADDED NEW ROW:\t"+temp+", "+str(len(already_added))+" NEW ROWS ADDED")
        except Exception as e:
            if 'No such file or directory' in str(e):
                error_count += 1
                print('ERROR #'+str(error_count)+':\t'+str(e))
    print("TOTAL ERRORS FROM LAST RUN:\t"+str(error_count))
    print("TOTAL ROWS ADDED:\t"+str(len(already_added)))