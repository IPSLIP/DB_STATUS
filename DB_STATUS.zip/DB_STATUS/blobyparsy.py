outie = open(r'C:\users\12246\desktop\db_status\googlebuckys_parsed.txt','w',encoding='utf-8',newline='')
for row in open(r'C:\users\12246\desktop\db_status\googlebuckeyss.txt','r',encoding='utf-8').read().splitlines():
    if '/url?q=' in row:
        row = row.replace('/url?q=','').replace('https://','').replace('http://','').replace('.s3.amazonaws.com','').split('/')[0]
        if 's3.amazonaws.com' not in row:
            print(row)
            outie.write(row+'\n')
            outie.flush()
outie.flush()