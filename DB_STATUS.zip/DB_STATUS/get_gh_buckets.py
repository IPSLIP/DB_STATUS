import requests,time
from socket import timeout
from bs4 import BeautifulSoup


s3_bucket_file = open(r'C:\users\12246\desktop\db_status\gh\s3_buckets_20220420.txt','a',newline='',encoding='utf-8')
azure_container_file = open(r'C:\users\12246\desktop\db_status\gh\azure_containers_20220420.txt','a',newline='',encoding='utf-8')
while True:
    x = requests.get('https://buckets.grayhatwarfare.com/random/buckets',timeout=5).text
    soup = BeautifulSoup(x,'html.parser')
    counter = 0
    find = True
    for l in (soup.find_all('tr')):
        if find:
            elems = l.text.strip().replace('\n','\t').split('\t')
            if len(elems)==14:
                print("NEW AZURE BLOB:\t"+elems[6].split('.blob.core.windows.net')[0]+","+elems[13])
            elif len(elems)>=7:
                print("NEW S3 BUCKET:\t"+elems[6].split('.s3')[0])
        else:
            try:
                if counter > 0:
                    if counter==2:
                        if temp+","+l.text.strip().replace('.blob.core.windows.net','') in open(r'C:\users\12246\desktop\db_status\gh\azure_containers.txt','r',newline='',encoding='utf-8').read():
                            print("SKIPPING ALREADY ADDED ROW\t"+temp+","+l.text.strip().replace('.blob.core.windows.net',''))
                        else:
                            print("ADDING NEW ROW\t"+temp+","+l.text.strip().replace('.blob.core.windows.net',''))
                            azure_container_file.write(temp+","+l.text.strip().replace('.blob.core.windows.net','')+"\n")
                        azure_container_file.flush()
                        counter,temp = 0,''
                    else:
                        counter +=1
                elif '.blob.core.windows.net' in l.text:
                    temp = l.text.strip().replace('.blob.core.windows.net','')
                    print("NEW AZURE ACCOUNT IDENTIFIED:\t"+temp+", WILL ADD ONCE CONTAINER FOUND")
                    counter += 1
                elif 'amazonaws.com' in l.text:
                    abc = l.text.split('.s3')[0]
                    #print("NEW S3 BUCKET IDENTIFIED:\t"+l.text.strip()+", PROCESSING...")
                    if abc in open(r'C:\users\12246\desktop\db_status\gh\s3_buckets_20220420.txt','r',newline='',encoding='utf-8').read():
                        print("SKIPPING ALREADY ADDED ROW\t"+abc)
                    else:
                        print("ADDING NEW ROW\t"+abc)
                        s3_bucket_file.write(abc+"\n")
                    s3_bucket_file.flush()
            except Exception as e:
                print("WEIRD ERROR:\t"+str(e))