import requests,time,psycopg2
import xml.etree.ElementTree as ET
from psycopg2 import Error
from urllib import parse
from socket import timeout
from bs4 import BeautifulSoup
from datetime import datetime,timezone

connection = psycopg2.connect(user="postgres",
                                  password="T1g3rw00dz$$",
                                  host="192.168.199.2",
                                  port="5432",
                                  database="azure_blob_scanner")
cursor = connection.cursor()
connection2 = psycopg2.connect(user="postgres",
                                  password="T1g3rw00dz$$",
                                  host="192.168.199.2",
                                  port="5432",
                                  database="s3_bucket_scanner")
cursor2 = connection2.cursor()

temp = ''
while True:
    x = requests.get('https://buckets.grayhatwarfare.com/random/buckets',timeout=5).text
    soup = BeautifulSoup(x,'html.parser')
    counter = 0
    for l in (soup.find_all('a') + soup.find_all('td')):
        try:
            #print(l.text.strip())
            if counter > 0:
                if counter==2:
                    print("NEW AZURE CONTAINER IDENTIFIED:\t"+l.text.strip().replace('.blob.core.windows.net','')+", PROCESSING...")
                    item = 'https://'+temp+'.blob.core.windows.net/'+l.text.strip().replace('.blob.core.windows.net','')+'?restype=container&comp=list'
                    r = requests.get(item).text
                    sel_st = """SELECT * FROM azure_files WHERE PUBLIC_CONTAINER='{0}' LIMIT 1""".format(item.replace('?restype=container&comp=list',''))
                    cursor.execute(sel_st)
                    record = cursor.fetchone()
                    connection.commit()
                    if record is not None:
                        print("ALREADY ADDED CONTAINER "+item.replace('?restype=container&comp=list',''))
                    else:
                        # insert new ID into database
                        no_error = True
                        for error_message in ['Server failed to authenticate the request.',
                        'Public access is not permitted on this storage account.',
                        'The specified resource does not exist.',
                        'The specified account is disabled.',
                        'This request is not authorized to perform this operation.',
                        'The account being accessed does not have sufficient permissions to execute this operation.',
                        'The specified account does not exist.']:
                            if error_message in r:
                                no_error = False
                                break
                        dt = datetime.now(timezone.utc)
                        if no_error:
                            root = ET.fromstring(r)
                            for i in root.iter():
                                if i.tag=='Blob':
                                    row_to_add = [item.replace('?restype=container&comp=list',''),"","","","None",dt,0]
                                    for k in i:
                                        if k.tag=='Name':
                                            row_to_add[1]=k.text
                                        if k.tag=='Url':
                                            row_to_add[2]=k.text
                                        if k.tag=='Properties':
                                            for l in k:
                                                if l.tag=='Last-Modified':
                                                    row_to_add[3] = l.text
                                                if l.tag=='Content-Length':
                                                    row_to_add[6] = l.text
                                            try:
                                                insert_string = """INSERT INTO azure_files (PUBLIC_CONTAINER,FILE_NAME,URL,LAST_MODIFIED,ERROR,ADDED_DATE,CONTENT_LENGTH) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}') """.format(row_to_add[0],row_to_add[1],row_to_add[2],row_to_add[3],row_to_add[4],row_to_add[5],row_to_add[6])
                                                cursor.execute(insert_string)
                                                connection.commit()
                                                if row_to_add[4]=="None":
                                                    print("EXECUTED QUERY\t"+insert_string)
                                                else:
                                                    print("ERROR WITH CONTAINER "+row_to_add[0]+", ADDING ANYWAY")
                                            except Exception as e:
                                                connection.commit()
                                                pass
                                            row_to_add = [item.replace('?restype=container&comp=list',''),"","","","None",dt,0]
                                            break
                        else:
                            try:
                                row_to_add = [item.replace('?restype=container&comp=list',''),"",item.replace('?restype=container&comp=list',''),"",r,dt,0]
                                insert_string = """INSERT INTO azure_files (PUBLIC_CONTAINER,FILE_NAME,URL,LAST_MODIFIED,ERROR,ADDED_DATE,CONTENT_LENGTH) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}') """.format(row_to_add[0],row_to_add[1],row_to_add[2],row_to_add[3],row_to_add[4],row_to_add[5],row_to_add[6])
                                cursor.execute(insert_string)
                                connection.commit()
                                if row_to_add[4]=="None":
                                    print("EXECUTED QUERY\t"+insert_string)
                                else:
                                    print("ERROR WITH CONTAINER "+row_to_add[0]+", ADDING ANYWAY")
                            except Exception as e:
                                connection.commit()
                                pass
                    counter,temp = 0,''
                else:
                    counter +=1
            if '.blob.core.windows.net' in l.text:
                temp = l.text.strip().replace('.blob.core.windows.net','')
                print("NEW AZURE ACCOUNT IDENTIFIED:\t"+temp)
                counter += 1
            if '.s3.amazonaws.com' in l.text:
                print("NEW S3 BUCKET IDENTIFIED:\t"+l.text.strip()+", PROCESSING...")
                item = 'https://'+l.text.strip()+'/?list-type=2'
                r = requests.get(item,timeout=5).text
                sel_st = """SELECT * FROM aws_files WHERE PUBLIC_BUCKET='{0}' LIMIT 1""".format(item)
                cursor2.execute(sel_st)
                record = cursor2.fetchone()
                connection2.commit()
                if record is not None:
                    print("ALREADY ADDED S3 BUCKET "+item,'')
                else:
                    # insert new ID into database
                    no_error = True
                    for error_message in ['The specified bucket does not exist']:
                        if error_message in r:
                            no_error = False
                            break
                    dt = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
                    row_to_add = [item,"",item,"",'The specified bucket does not exist',dt,0,'']
                    if no_error:
                        row_to_add[4]="None"
                        root = ET.fromstring(r)
                        for i in root.iter():
                            tag = i.tag.replace('{http://s3.amazonaws.com/doc/2006-03-01/}','')
                            if tag=='Key':
                                row_to_add[1]= i.text.replace("'","%27")
                                scheme, netloc, path, query, fragment = parse.urlsplit(item.replace('?list-type=2','')+i.text)
                                path = parse.quote(path)
                                row_to_add[2]= parse.urlunsplit((scheme, netloc, path, query, fragment))
                            elif tag=='LastModified':
                                row_to_add[3]=i.text
                            elif tag=='Size':
                                row_to_add[6] = int(i.text)
                                print("NEW FILE "+row_to_add[2]+" FOUND!")
                                print(str(row_to_add))
                                try:
                                    insert_string = """INSERT INTO aws_files(PUBLIC_BUCKET,FILE_NAME,URL,LAST_MODIFIED,ERROR,ADDED_DATE,CONTENT_LENGTH,TRUNCATED) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}') """.format(row_to_add[0],row_to_add[1],row_to_add[2],row_to_add[3],row_to_add[4],row_to_add[5],row_to_add[6],row_to_add[7])
                                    cursor2.execute(insert_string)
                                    connection2.commit()
                                    if row_to_add[4]=="None":
                                        print("EXECUTED QUERY\t"+insert_string)
                                    else:
                                        print("ERROR WITH CONTAINER "+row_to_add[0]+", ADDING ANYWAY")
                                except Exception as e:
                                    print("ERROR:\t"+str(e))
                                    connection2.commit()
                                    pass
                                row_to_add = [item,"","","",row_to_add[4],dt,0,row_to_add[7]]
                    else:
                        try:
                            insert_string = """INSERT INTO aws_files(PUBLIC_BUCKET,FILE_NAME,URL,LAST_MODIFIED,ERROR,ADDED_DATE,CONTENT_LENGTH,TRUNCATED) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}') """.format(row_to_add[0],row_to_add[1],row_to_add[2],row_to_add[3],row_to_add[4],row_to_add[5],row_to_add[6],row_to_add[7])
                            cursor2.execute(insert_string)
                            connection2.commit()
                            if row_to_add[4]=="None":
                                print("EXECUTED QUERY\t"+insert_string)
                            else:
                                print("ERROR WITH CONTAINER "+row_to_add[0]+", ADDING ANYWAY")
                        except Exception as e:
                            print("ERROR:\t"+str(e))
                            connection2.commit()
                            pass
                        row_to_add = [item,"","","",row_to_add[4],dt,0,row_to_add[7]]
        except Exception as e:
            print("ERROR:\t"+str(e))
    print("PAUSING FOR ONE MINUTE")
    time.sleep(60)